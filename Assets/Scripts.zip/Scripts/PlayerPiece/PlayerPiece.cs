using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPiece : MonoBehaviour
{
    public bool isReady;
    public bool canMove;

    public bool moveNow;
    public int numberOfStepsAlreadyMoved;

    Coroutine moveSteps_Coroutine;

    public PathObjectsParent pathsParent;
    public PathPoint previousPathPoint;
    public PathPoint currentPathPoint;
    public PhotonView photonView;
    public SpriteRenderer spriteRenderer;
    [SerializeField] private float blinkInterval = 0.4f;

    private byte selfId;
    private Coroutine blinkCoroutine;

    private void Awake()
    {
        pathsParent = FindAnyObjectByType<PathObjectsParent>();
        photonView = GetComponent<PhotonView>();
        //pathsParent = FindObjectOfType<PathObjectsParent>();
    }
    
    public void StartBlinking()
    {
        blinkCoroutine ??= StartCoroutine(Blink());
    }

    public void StopBlinking()
    {
        if (blinkCoroutine == null) return;
        
        StopCoroutine(blinkCoroutine);
        blinkCoroutine = null;
        spriteRenderer.enabled = true;  // Ensure sprite is visible when stopping
    }

    private IEnumerator Blink()
    {
        while (true)
        {
            spriteRenderer.enabled = !spriteRenderer.enabled;  // Toggle visibility
            yield return new WaitForSeconds(blinkInterval);    // Wait for the interval
        }
    }

    public void SetSelfId(byte selfId)
    {
        this.selfId = selfId;
    }

    public void MoveSteps(PathPoint[] pathPointsToMoveOn_)
    {
        if (canMove)
        {
            moveSteps_Coroutine = StartCoroutine(MoveSteps_Enum(pathPointsToMoveOn_));
        }
    }

    public void MakePlayerReadyToMove(PathPoint[] pathPointsToMoveOn_)
    {
        isReady = true;
        transform.position = pathPointsToMoveOn_[0].transform.position;
        numberOfStepsAlreadyMoved = 1;

        previousPathPoint = pathPointsToMoveOn_[0];
        currentPathPoint = pathPointsToMoveOn_[0];
        currentPathPoint.AddPlayerPiece(this);
        GameManager.Instance.RemovePathPoint(previousPathPoint);
        GameManager.Instance.AddPathPoint(currentPathPoint);
        GameManager.Instance.canDiceRoll = true;
        GameManager.Instance.selfDice = true;
        GameManager.Instance.transferDice = false;
    }

    IEnumerator MoveSteps_Enum(PathPoint[] pathPointsToMoveOn_)
    {
        GameManager.Instance.transferDice = false;
        yield return new WaitForSeconds(0.25f);
        int numOfStepsToMove = GameManager.Instance.numOfStepsToMove;

        if (canMove)
        {
            previousPathPoint.RescaleAndRepositionAllPlayerPieces();
            for (int i = numberOfStepsAlreadyMoved; i < (numberOfStepsAlreadyMoved + numOfStepsToMove); i++)
            {
                if (isPathPointsAvailableToMove(numOfStepsToMove, numberOfStepsAlreadyMoved, pathPointsToMoveOn_))
                {
                    transform.position = pathPointsToMoveOn_[i].transform.position;
                    yield return new WaitForSeconds(0.25f);
                }
            }
        }

        if (isPathPointsAvailableToMove(numOfStepsToMove, numberOfStepsAlreadyMoved, pathPointsToMoveOn_))
        {
            numberOfStepsAlreadyMoved += numOfStepsToMove;

            GameManager.Instance.RemovePathPoint(previousPathPoint);
            previousPathPoint.RemovePlayerPiece(this);
            currentPathPoint = pathPointsToMoveOn_[numberOfStepsAlreadyMoved - 1];

            if (currentPathPoint.AddPlayerPiece(this))
            {
                if (numberOfStepsAlreadyMoved == 57) // Assuming 57 is the final position
                {
                    GameManager.Instance.selfDice = true;
                   // PlayerReachedHome();
                }
                else
                {
                    if (GameManager.Instance.numOfStepsToMove != 6)
                    {
                        GameManager.Instance.transferDice = true;
                    }
                    else
                    {
                        GameManager.Instance.selfDice = true;
                    }
                }
            }
            else
            {
                GameManager.Instance.selfDice = true;
            }

            GameManager.Instance.AddPathPoint(currentPathPoint);
            previousPathPoint = currentPathPoint;
            GameManager.Instance.numOfStepsToMove = 0;
        }

        canMove = true;
        GameManager.Instance.RollingDiceManager();

        if (moveSteps_Coroutine != null)
        {
            StopCoroutine(moveSteps_Coroutine);
        }
    }

    bool isPathPointsAvailableToMove(int numOfStepsToMove_, int numOfStepsAlreadyMoved_, PathPoint[] pathPointsToMoveOn_)
    {
        int leftNumOfPathPoints = pathPointsToMoveOn_.Length - numOfStepsAlreadyMoved_;
        return leftNumOfPathPoints >= numOfStepsToMove_;
    }

    public void OnPieceIsTappedToMoveRPC()
    {
        photonView.RPC(nameof(OnPieceIsTappedToMove), RpcTarget.AllBuffered);
    }

    [PunRPC]
    public virtual void OnPieceIsTappedToMove()
    {

    }
}

