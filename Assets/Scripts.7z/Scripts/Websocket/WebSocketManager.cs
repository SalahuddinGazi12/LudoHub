using System;
using System.Collections;
using System.Collections.Generic;
using NativeWebSocket;
using UnityEngine;
using UnityEngine.Events;

public class WebSocketManager : MonoBehaviour
{
    public static WebSocketManager Instance { get; private set; }

    [SerializeField] private string serverUrl = "ws://your-game-server.com:8080";

    private WebSocket websocket;
    private string playerId;
    private string currentRoomId;

    // Events
    public UnityEvent OnConnected;
    public UnityEvent<string> OnDisconnected;
    public UnityEvent<string> OnError;
    public UnityEvent<string> OnRoomCreated;
    public UnityEvent<string> OnRoomJoined;
    public UnityEvent<List<PlayerData>> OnPlayersUpdated;
    public UnityEvent<GameStartData> OnGameStarted;

    private Dictionary<string, Action<string>> eventHandlers = new Dictionary<string, Action<string>>();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        // Register default event handlers
        RegisterEventHandler("room_created", HandleRoomCreated);
        RegisterEventHandler("room_joined", HandleRoomJoined);
        RegisterEventHandler("players_updated", HandlePlayersUpdated);
        RegisterEventHandler("game_started", HandleGameStarted);
    }

    public async void Connect(string playerId)
    {
        this.playerId = playerId;

        websocket = new WebSocket(serverUrl);

        websocket.OnOpen += () =>
        {
            Debug.Log("Connection open!");
            OnConnected?.Invoke();

            // Send player ID to server
            SendWebSocketMessage("set_id", $"{{\"playerId\":\"{playerId}\"}}");
        };

        websocket.OnError += (e) =>
        {
            Debug.LogError("Error! " + e);
            OnError?.Invoke(e);
        };

        websocket.OnClose += (e) =>
        {
            Debug.Log("Connection closed!");
            OnDisconnected?.Invoke(e.ToString());
        };

        websocket.OnMessage += (bytes) =>
        {
            var message = System.Text.Encoding.UTF8.GetString(bytes);
            Debug.Log("Received Message: " + message);
            HandleSocketMessage(message);
        };

        await websocket.Connect();
    }

    private void HandleSocketMessage(string message)
    {
        try
        {
            var msgData = JsonUtility.FromJson<SocketMessage>(message);

            if (eventHandlers.TryGetValue(msgData.eventName, out var handler))
            {
                handler(msgData.data);
            }
            else
            {
                Debug.LogWarning($"No handler registered for event: {msgData.eventName}");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"Error processing message: {e.Message}");
        }
    }

    public void RegisterEventHandler(string eventName, Action<string> handler)
    {
        if (eventHandlers.ContainsKey(eventName))
        {
            eventHandlers[eventName] += handler;
        }
        else
        {
            eventHandlers[eventName] = handler;
        }
    }

    public void UnregisterEventHandler(string eventName, Action<string> handler)
    {
        if (eventHandlers.ContainsKey(eventName))
        {
            eventHandlers[eventName] -= handler;
            if (eventHandlers[eventName] == null)
            {
                eventHandlers.Remove(eventName);
            }
        }
    }

    public void JoinRandomMatch(string matchFee, int roomSize)
    {
        var data = $"{{\"game_mode\":\"Online\",\"match_fee\":\"{matchFee}\",\"room_size\":{roomSize}}}";
        SendWebSocketMessage("join", data);
    }

    public void CreatePrivateRoom(string matchFee, int roomSize)
    {
        var data = $"{{\"game_mode\":\"Private\",\"match_fee\":\"{matchFee}\",\"room_size\":{roomSize}}}";
        SendWebSocketMessage("create_room", data);
    }

    public void JoinPrivateRoom(string roomCode)
    {
        var data = $"{{\"game_code\":\"{roomCode}\"}}";
        SendWebSocketMessage("join_with_code", data);
    }

    private async void SendWebSocketMessage(string eventName, string data)
    {
        if (websocket.State == WebSocketState.Open)
        {
            var message = new SocketMessage
            {
                eventName = eventName,
                data = data
            };

            await websocket.SendText(JsonUtility.ToJson(message));
        }
        else
        {
            Debug.LogWarning("WebSocket not connected. Message not sent.");
        }
    }

    private void HandleRoomCreated(string data)
    {
        var roomData = JsonUtility.FromJson<RoomCreatedData>(data);
        currentRoomId = roomData.roomId;
        OnRoomCreated?.Invoke(roomData.roomCode);
    }

    private void HandleRoomJoined(string data)
    {
        var roomData = JsonUtility.FromJson<RoomJoinedData>(data);
        currentRoomId = roomData.roomId;
        OnRoomJoined?.Invoke(roomData.roomId);
    }

    private void HandlePlayersUpdated(string data)
    {
        var playersData = JsonUtility.FromJson<PlayersUpdatedData>(data);
        OnPlayersUpdated?.Invoke(playersData.players);
    }

    private void HandleGameStarted(string data)
    {
        var gameData = JsonUtility.FromJson<GameStartData>(data);
        OnGameStarted?.Invoke(gameData);
    }

    private void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        if (websocket != null)
        {
            websocket.DispatchMessageQueue();
        }
#endif
    }

    private async void OnApplicationQuit()
    {
        if (websocket != null)
        {
            await websocket.Close();
        }
    }
}

[Serializable]
public class SocketMessage
{
    public string eventName;
    public string data;
}

[Serializable]
public class RoomCreatedData
{
    public string roomId;
    public string roomCode;
}

[Serializable]
public class RoomJoinedData
{
    public string roomId;
}

[Serializable]
public class PlayersUpdatedData
{
    public List<PlayerData> players;
}

[Serializable]
public class PlayerData
{
    public string playerId;
    public string playerName;
    public DiceColor diceColor;
}

[Serializable]
public class GameStartData
{
    public string sessionId;
    public int entryFee;
    public List<PlayerData> players;
    public DiceColor startingPlayer;
}