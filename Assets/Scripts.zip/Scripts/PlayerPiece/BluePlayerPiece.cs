using Photon.Pun;
using UnityEngine;

public class BluePlayerPiece : PlayerPiece
{
    public RollingDice blueHomeRollingDice;
    private bool hasTouched = false;

    private void Start()
    {
        // Optionally initialize anything here
    }

    private void Update()
    {
        // Handle touch input for mobile devices
        if (DataManager.Instance.GameType == GameType.Multiplayer)
        {
            if (DataManager.Instance.ActiveDiceColor == DataManager.Instance.OwnDiceColor)
            {
                // Check if a touch is detected and is within the player's piece collider
                if (Input.touchCount > 0 && !hasTouched)
                {
                    Touch touch = Input.GetTouch(0);
                    Ray ray = Camera.main.ScreenPointToRay(touch.position);
                    RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction);

                    // Only process touch if it hits this specific BluePlayerPiece
                    if (hit.collider != null && hit.collider.gameObject == gameObject)
                    {
                        OnPieceIsTappedToMoveRPC();
                        hasTouched = true; // Mark that the piece has been touched
                    }
                }
            }
        }
        else
        {
            // Handle for non-multiplayer mode
            if (Input.touchCount > 0 && !hasTouched)
            {
                Touch touch = Input.GetTouch(0);
                Ray ray = Camera.main.ScreenPointToRay(touch.position);
                RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction);

                // Only trigger OnPieceIsTappedToMove if the touch is on the BluePlayerPiece
                if (hit.collider != null && hit.collider.gameObject == gameObject)
                {
                    OnPieceIsTappedToMove();
                    hasTouched = true; // Mark that the piece has been touched
                }
            }
        }
    }

    [PunRPC]
    public override void OnPieceIsTappedToMove()
    {
        if (GameManager.Instance.rolledDice != null)
        {
            RollingDice bluehomedice = GameObject.Find("Blue").transform.GetChild(0).GetComponent<RollingDice>();
            RollingDice bluehomedice1 = GameObject.Find("Blue").transform.GetChild(1).GetComponent<RollingDice>();
            if (bluehomedice.isActiveAndEnabled)
            {
                blueHomeRollingDice = bluehomedice;
            }
            else if (bluehomedice1.isActiveAndEnabled)
            {
                blueHomeRollingDice = bluehomedice1;
            }

            if (!isReady)
            {
                if (GameManager.Instance.rolledDice == blueHomeRollingDice && GameManager.Instance.numOfStepsToMove == 6)
                {
                    GameManager.Instance.blueOutPlayers += 1;
                    MakePlayerReadyToMove(pathsParent.bluePathPoints);
                    GameManager.Instance.numOfStepsToMove = 0;
                    return;
                }
            }
            if (GameManager.Instance.rolledDice == blueHomeRollingDice && isReady)
            {
                canMove = true;
                MoveSteps(pathsParent.bluePathPoints);
            }
        }
    }
}
