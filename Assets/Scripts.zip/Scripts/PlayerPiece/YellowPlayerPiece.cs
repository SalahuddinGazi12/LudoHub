using Photon.Pun;
using UnityEngine;

public class YellowPlayerPiece : PlayerPiece
{
    public RollingDice yellowHomeRollingDice;
    private bool hasTouched = false;

    private void Start()
    {
        // yellowHomeRollingDice = GetComponentInParent<YellowHome>().rollingDice;
    }

    private void Update()
    {
        // Handle touch input for mobile devices
        if (DataManager.Instance.GameType == GameType.Multiplayer)
        {
            if (DataManager.Instance.ActiveDiceColor == DataManager.Instance.OwnDiceColor)
            {
                // Check if a touch is detected and is within the player's piece collider
                if (Input.touchCount > 0 && !hasTouched)
                {
                    Touch touch = Input.GetTouch(0);
                    Ray ray = Camera.main.ScreenPointToRay(touch.position);
                    RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction);

                    // Check if the touch hits the specific GreenPlayerPiece
                    if (hit.collider != null && hit.collider.gameObject == gameObject)
                    {
                        OnPieceIsTappedToMoveRPC();
                        hasTouched = true; // Only register the first touch
                    }
                }
            }
        }
        else
        {
            // Handle for non-multiplayer mode
            if (Input.touchCount > 0 && !hasTouched)
            {
                Touch touch = Input.GetTouch(0);
                Ray ray = Camera.main.ScreenPointToRay(touch.position);
                RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction);

                // Only trigger OnPieceIsTappedToMove if touch is on this specific object
                if (hit.collider != null && hit.collider.gameObject == gameObject)
                {
                    OnPieceIsTappedToMove();
                    hasTouched = true; // Only register the first touch
                }
            }
        }
    }

    [PunRPC]
    public override void OnPieceIsTappedToMove()
    {
        if (GameManager.Instance.rolledDice != null)
        {
            RollingDice yellowhomedice = GameObject.Find("Yellow").transform.GetChild(0).GetComponent<RollingDice>();
            RollingDice yellowhomedice1 = GameObject.Find("Yellow").transform.GetChild(1).GetComponent<RollingDice>();
            if (yellowhomedice.isActiveAndEnabled)
            {
                yellowHomeRollingDice = yellowhomedice;
            }
            else if (yellowhomedice1.isActiveAndEnabled)
                yellowHomeRollingDice = yellowhomedice1;

            if (!isReady)
            {
                if (GameManager.Instance.rolledDice == yellowHomeRollingDice && GameManager.Instance.numOfStepsToMove == 6)
                {
                    GameManager.Instance.yellowOutPlayers += 1;
                    MakePlayerReadyToMove(pathsParent.yellowPathPoints);
                    GameManager.Instance.numOfStepsToMove = 0;
                    return;
                }
            }
            if (GameManager.Instance.rolledDice == yellowHomeRollingDice && isReady)
            {
                canMove = true;
                MoveSteps(pathsParent.yellowPathPoints);
            }
        }
    }
}
