using ExitGames.Client.Photon.StructWrapping;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathPoint : MonoBehaviour
{
    PathPoint[] pathPointToMoveOn_;
    public PathObjectsParent pathObjParent;
    public List<PlayerPiece> playerPiecesList = new List<PlayerPiece>();

    private void Start()
    {
        pathObjParent = GetComponentInParent<PathObjectsParent>();
    }


    public bool AddPlayerPiece(PlayerPiece playerPiece_)
    {

        //if (this.name.Contains("RedCentreHomePoint"))
        //{
        //    CompletedRed(playerPiece_);
        //}
        //else if(this.name.Contains("YellowCentreHomePoint"))
        //{
        //    CompletedYellow(playerPiece_);
        //}
        //else if (this.name.Contains("BlueCentreHomePoint"))
        //{
        //    CompletedBlue(playerPiece_);
        //}
        //else if (this.name.Contains("GreenCentreHomePoint"))
        //{
        //    CompletedGreen(playerPiece_);
        //}
        if (this.name != "PathPoint" && this.name != "PathPoint (8)" && this.name != "PathPoint (13)" && this.name != "PathPoint (21)" && this.name != "PathPoint (26)" && this.name != "PathPoint (34)" && this.name != "PathPoint (39)" && this.name != "PathPoint (47)" && this.name != "CentreHomePoint")
        {
            if (playerPiecesList.Count == 1)
            {
                string prevPlayerPieceName = playerPiecesList[0].name;
                string currentPlayerPieceName = playerPiece_.name;
                currentPlayerPieceName = currentPlayerPieceName.Substring(0, currentPlayerPieceName.Length - 4);
                if (!prevPlayerPieceName.Contains(currentPlayerPieceName))
                {
                    playerPiecesList[0].isReady = false;

                    StartCoroutine(revertOnStart(playerPiecesList[0]));


                    playerPiecesList[0].numberOfStepsAlreadyMoved = 0;
                    RemovePlayerPiece(playerPiecesList[0]);
                    playerPiecesList.Add(playerPiece_);

                    return false;
                }
            }
        }
        addPlayer(playerPiece_);
        return true;
    }

    IEnumerator revertOnStart(PlayerPiece playerPiece_)
    {
        if (playerPiece_.name.Contains("Red"))
        {
            GameManager.Instance.redOutPlayers -= 1;
            pathPointToMoveOn_ = pathObjParent.redPathPoints;
        }
        else if (playerPiece_.name.Contains("Blue"))
        {
            GameManager.Instance.blueOutPlayers -= 1;
            pathPointToMoveOn_ = pathObjParent.bluePathPoints;
        }
        else if (playerPiece_.name.Contains("Yellow"))
        {
            GameManager.Instance.yellowOutPlayers -= 1;
            pathPointToMoveOn_ = pathObjParent.yellowPathPoints;
        }
        else if (playerPiece_.name.Contains("Green"))
        {
            GameManager.Instance.greenOutPlayers -= 1;
            pathPointToMoveOn_ = pathObjParent.greenPathPoints;
        }

        for (int i = playerPiece_.numberOfStepsAlreadyMoved; i >= 0; i--)
        {
            playerPiece_.transform.position = pathPointToMoveOn_[i].transform.position;
            yield return new WaitForSeconds(0.05f);
        }

        playerPiece_.transform.position = pathObjParent.BasePoints[BasePointPosition(playerPiece_.name)].transform.position;

    }

    int BasePointPosition(string name)
    {

        for (int i = 0; i < pathObjParent.BasePoints.Length; i++)
        {
            if (pathObjParent.BasePoints[i].name == name)
            {
                return i;
            }
        }
        return -1;
    }

    void addPlayer(PlayerPiece playerPiece_)
    {
        playerPiecesList.Add(playerPiece_);
        RescaleAndRepositionAllPlayerPieces();
    }
    public void RemovePlayerPiece(PlayerPiece PlayerPiece_)
    {
        if (playerPiecesList.Contains(PlayerPiece_))
        {
            playerPiecesList.Remove(PlayerPiece_);
            RescaleAndRepositionAllPlayerPieces();
        }
    }


    public void CompletedRed(PlayerPiece playerPiece_)
    {
        if (playerPiece_.name.Contains("Red"))
        {
            GameManager.Instance.redCompletePlayer += 1;
            GameManager.Instance.redOutPlayers -= 1;
          //  playerPiece_.transform.position = GameObject.Find("RedCentreHomePoint").transform.position;
            if (GameManager.Instance.redCompletePlayer == 4)
            {
                ShowCelebration();
            }
        }
    }
    public void CompletedBlue(PlayerPiece playerPiece_)
    {
        if (playerPiece_.name.Contains("Blue"))
        {
            GameManager.Instance.blueCompletePlayer += 1;
            GameManager.Instance.blueOutPlayers -= 1;
          //  playerPiece_.transform.position = GameObject.Find("BlueCentreHomePoint").transform.position;
            if (GameManager.Instance.blueCompletePlayer == 4)
            {
                ShowCelebration();
            }
        }
    }
    public void CompletedYellow(PlayerPiece playerPiece_)
    {
        if (playerPiece_.name.Contains("Yellow"))
        {
            GameManager.Instance.yellowCompletePlayer += 1;
            GameManager.Instance.yellowOutPlayers -= 1;
           // playerPiece_.transform.position = GameObject.Find("YellowCentreHomePoint").transform.position;
            if (GameManager.Instance.yellowCompletePlayer == 4)
            {
                ShowCelebration();
            }
        }
    }
    public void CompletedGreen(PlayerPiece playerPiece_)
    { 
        if (playerPiece_.name.Contains("Green") )
        {
            GameManager.Instance.greenCompletePlayer += 1;
            GameManager.Instance.greenOutPlayers -= 1;
           // playerPiece_.transform.position = GameObject.Find("GreenCentreHomePoint").transform.position;
            if (GameManager.Instance.greenCompletePlayer == 4)
            {
                ShowCelebration();
            }
        }
    }
    void ShowCelebration()
    {
        GameManager.Instance.CheckForWinner();
    }
    public void RescaleAndRepositionAllPlayerPieces()
    {
        int plsCount = playerPiecesList.Count;
        bool isOdd = plsCount % 2 != 0;
        int spriteLayers = 0;

        int extent = plsCount / 2;
        int counter = 0;

        // Scale reduction factor (0.9 means 90% of the original size)
        float scaleReductionFactor = 0.9f;

        // Determine the currently active player based on active dice
        string activeColor = GetActivePlayerColor();

        // Adjust for odd count
        if (isOdd)
        {
            for (int i = -extent; i <= extent; i++)
            {
                // Apply the scale reduction factor
                float newScale = pathObjParent.scales[plsCount - 1] * scaleReductionFactor;
                playerPiecesList[counter].transform.localScale = new Vector3(newScale, newScale, 1f);
                playerPiecesList[counter].transform.position = new Vector3(transform.position.x + (i * pathObjParent.positionsDifference[plsCount - 1]), transform.position.y, 0f);
                counter++;
            }
        }
        // Adjust for even count
        else
        {
            for (int i = -extent; i < extent; i++)
            {
                // Apply the scale reduction factor
                float newScale = pathObjParent.scales[plsCount - 1] * scaleReductionFactor;
                playerPiecesList[counter].transform.localScale = new Vector3(newScale, newScale, 1f);
                playerPiecesList[counter].transform.position = new Vector3(transform.position.x + (i * pathObjParent.positionsDifference[plsCount - 1]), transform.position.y, 0f);
                counter++;
            }
        }

        // Set sprite layers to avoid overlap
        for (int i = 0; i < playerPiecesList.Count; i++)
        {
            SpriteRenderer spriteRenderer = playerPiecesList[i].GetComponentInChildren<SpriteRenderer>();

            // Check if the player's color matches the active color
            if (playerPiecesList[i].name.Contains(activeColor))
            {
                // Set a higher sorting order for the active player's pieces
                spriteRenderer.sortingOrder = spriteLayers + 10; // Adding 10 to prioritize active player
            }
            else
            {
                spriteRenderer.sortingOrder = spriteLayers;
            }
            spriteLayers++;
        }
    }

    // Helper method to determine the active player's color based on the active dice
    private string GetActivePlayerColor()
    {
        // Check which dice is currently active and return corresponding player color
        if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[0])
        {
            return "Blue";
        }
        else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[1])
        {
            return "Red";
        }
        else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[2])
        {
            return "Green";
        }
        else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[3])
        {
            return "Yellow";
        }

        // Default fallback, though this case shouldn't normally happen
        return string.Empty;
    }
}


