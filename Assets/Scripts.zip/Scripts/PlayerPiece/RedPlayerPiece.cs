using Photon.Pun;
using UnityEngine;

public class RedPlayerPiece : PlayerPiece
{
    public RollingDice redHomeRollingDice;
    private bool hasTouched = false;

    private void Start()
    {
        // Optionally initialize anything here
    }

    private void Update()
    {
        // Handle touch input for mobile devices
        if (DataManager.Instance.GameType == GameType.Multiplayer)
        {
            if (DataManager.Instance.ActiveDiceColor == DataManager.Instance.OwnDiceColor)
            {
                // Check if a touch is detected and is within the player's piece collider
                if (Input.touchCount > 0 && !hasTouched)
                {
                    Touch touch = Input.GetTouch(0);
                    Ray ray = Camera.main.ScreenPointToRay(touch.position);
                    RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction);

                    // Check if the touch hits the specific RedPlayerPiece
                    if (hit.collider != null && hit.collider.gameObject == gameObject)
                    {
                        OnPieceIsTappedToMoveRPC();
                        hasTouched = true; // Only register the first touch
                    }
                }
            }
        }
        else
        {
            // Handle for non-multiplayer mode
            if (Input.touchCount > 0 && !hasTouched)
            {
                Touch touch = Input.GetTouch(0);
                Ray ray = Camera.main.ScreenPointToRay(touch.position);
                RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction);

                // Only trigger OnPieceIsTappedToMove if touch is on this specific object
                if (hit.collider != null && hit.collider.gameObject == gameObject)
                {
                    OnPieceIsTappedToMove();
                    hasTouched = true; // Only register the first touch
                }
            }
        }
    }

    [PunRPC]
    public override void OnPieceIsTappedToMove()
    {
        if (GameManager.Instance.rolledDice != null)
        {
            RollingDice redhomedice = GameObject.Find("Red").transform.GetChild(0).GetComponent<RollingDice>();
            RollingDice redhomedice1 = GameObject.Find("Red").transform.GetChild(1).GetComponent<RollingDice>();
            if (redhomedice.isActiveAndEnabled)
            {
                redHomeRollingDice = redhomedice;
            }
            else if (redhomedice1.isActiveAndEnabled)
            {
                redHomeRollingDice = redhomedice1;
            }

            if (!isReady)
            {
                Debug.Log($"GameManager rolledDice: {GameManager.Instance.rolledDice}");
                Debug.Log($"Red Player rolledDice: {redHomeRollingDice}");
                Debug.Log($"Are they equal? {GameManager.Instance.rolledDice == redHomeRollingDice}");

                if (GameManager.Instance.rolledDice == redHomeRollingDice && GameManager.Instance.numOfStepsToMove == 6)
                {
                    GameManager.Instance.redOutPlayers += 1;
                    MakePlayerReadyToMove(pathsParent.redPathPoints);
                    GameManager.Instance.numOfStepsToMove = 0;
                    return;
                }
            }

            if (GameManager.Instance.rolledDice == redHomeRollingDice && isReady)
            {
                canMove = true;
                MoveSteps(pathsParent.redPathPoints);
            }
        }
    }
}
