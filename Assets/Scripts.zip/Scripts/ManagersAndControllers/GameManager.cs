using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public RollingDice rolledDice;
    public int numOfStepsToMove;
    public bool canMove = true;
    public DiceColor activeDiceColor = DiceColor.Unknown;
    public DiceAnimationController diceAnimationController;

    List<PathPoint> playerOnPathPointsList = new List<PathPoint>();
    public bool canDiceRoll = true;
    public bool transferDice = false;
    public bool selfDice = false;

    public int blueOutPlayers;
    public int redOutPlayers;
    public int greenOutPlayers;
    public int yellowOutPlayers;

    public int blueCompletePlayer;
    public int redCompletePlayer;
    public int greenCompletePlayer;
    public int yellowCompletePlayer;

    public RollingDice[] manageRollingDice;
    public RollingDice[] manageRollingDiceM;
    public PlayerPiece[] redPlayerPiece;
    public PlayerPiece[] bluePlayerPiece;
    public PlayerPiece[] yellowPlayerPiece;
    public PlayerPiece[] greenPlayerPiece;
    public SpriteRenderer[] blinksprite;
    public int TotalPlayerCanPlay { get; private set; }

    public AudioSource audioSource;
    public GameObject endgame;
   // public TextMeshProUGUI wontext;

    // Booleans to track which player can move
    private bool blueCanMove = true;
    private bool redCanMove = true;
    private bool greenCanMove = true;
    private bool yellowCanMove = true;

    private PhotonView photonView;

    public GamePlayer OwnPlayer { get; private set; }
    public GamePlayer OpponentPlayer { get; private set; }

    private const byte GAME_OVER_EVENT_CODE = 1;
    private const byte CURRENT_TURN_EVENT_CODE = 2;

    private List<DiceColor> currentBoardsPlayers;


    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        audioSource = GetComponent<AudioSource>();

        photonView = GetComponent<PhotonView>();
        currentBoardsPlayers = new List<DiceColor>();
        //DontDestroyOnLoad(gameObject);

        //if(DataManager.Instance.GameType == GameType.Multiplayer)
        //{
        //    SetPieceId(redPlayerPiece);
        //    SetPieceId(bluePlayerPiece);
        //    SetPieceId(yellowPlayerPiece);
        //    SetPieceId(greenPlayerPiece);
        //}
    }

    public void SetPlayerAvatar(Sprite avatarSprite, DiceColor diceColor)
    {
        manageRollingDice[(int)diceColor].SetSelfAvatar(avatarSprite);
    }

    public void RotateAllPieces(Transform localTrans)
    {
        Vector3 localRot = localTrans.localEulerAngles * -1;

        // Group all player pieces into one list of IEnumerable to support different collection types
        List<IEnumerable<PlayerPiece>> allPlayerPieces = new List<IEnumerable<PlayerPiece>>
    {
        redPlayerPiece,
        bluePlayerPiece,
        yellowPlayerPiece,
        greenPlayerPiece
    };

        // Iterate through each color's pieces
        foreach (IEnumerable<PlayerPiece> playerPieces in allPlayerPieces)
        {
            foreach (PlayerPiece playerPiece in playerPieces)
            {
                playerPiece.transform.localEulerAngles = localRot;
                playerPiece.transform.localPosition = new Vector3(playerPiece.transform.localPosition.x, playerPiece.transform.localPosition.y - 0.32f, playerPiece.transform.localPosition.z);
            }
        }
    }

    public void ChangeAllPieceSprite(int index)
    {
        foreach (PlayerPiece playerPiece in redPlayerPiece)
        {
            playerPiece.spriteRenderer.sprite = DataManager.Instance.boardGraphics[index].redPieceSprite;
        }
        
        foreach (PlayerPiece playerPiece in bluePlayerPiece)
        {
            playerPiece.spriteRenderer.sprite = DataManager.Instance.boardGraphics[index].bluePieceSprite;
        }
        
        foreach (PlayerPiece playerPiece in yellowPlayerPiece)
        {
            playerPiece.spriteRenderer.sprite = DataManager.Instance.boardGraphics[index].yellowPieceSprite;
        }
        
        foreach (PlayerPiece playerPiece in greenPlayerPiece)
        {
            playerPiece.spriteRenderer.sprite = DataManager.Instance.boardGraphics[index].greenPieceSprite;
        }
    }
    public void ChangeAllblinkSprite(int index)
    {
        // Set the sprites
        blinksprite[0].sprite = DataManager.Instance.boardGraphics[index].redBlinkSprite;
        blinksprite[1].sprite = DataManager.Instance.boardGraphics[index].blueBlinkSprite;
        blinksprite[2].sprite = DataManager.Instance.boardGraphics[index].yellowBlinkSprite;
        blinksprite[3].sprite = DataManager.Instance.boardGraphics[index].greenBlinkSprite;

        // Define the default color
        Color defaultColor = Color.white; // Or whatever your default color is
        Color blinkColor = new Color(0.5f, 1.0f, 0.5f, 1.0f); // Blink color when index is 0

        // Apply the appropriate color based on index
        foreach (var sprite in blinksprite)
        {
            var spriteRenderer = sprite.GetComponent<SpriteRenderer>();
            spriteRenderer.color = (index == 0) ? blinkColor : defaultColor;
        }
    }
    public void StartOrStopRedPieceBlinking(bool shouldStart)
    {
        if (shouldStart)
        {
            foreach (PlayerPiece playerPiece in redPlayerPiece)
            {
                playerPiece.StartBlinking();
            }
            
            return;
        }
        
        foreach (PlayerPiece playerPiece in redPlayerPiece)
        {
            playerPiece.StopBlinking();
        }
    }
    
    public void StartOrStopBluePieceBlinking(bool shouldStart)
    {
        if (shouldStart)
        {
            foreach (PlayerPiece playerPiece in bluePlayerPiece)
            {
                playerPiece.StartBlinking();
            }
            
            return;
        }
        
        foreach (PlayerPiece playerPiece in bluePlayerPiece)
        {
            playerPiece.StopBlinking();
        }
    }
    
    public void StartOrStopYellowPieceBlinking(bool shouldStart)
    {
        if (shouldStart)
        {
            foreach (PlayerPiece playerPiece in yellowPlayerPiece)
            {
                playerPiece.StartBlinking();
            }
            
            return;
        }
        
        foreach (PlayerPiece playerPiece in yellowPlayerPiece)
        {
            playerPiece.StopBlinking();
        }
    }
    
    public void StartOrStopGreenPieceBlinking(bool shouldStart)
    {
        if (shouldStart)
        {
            foreach (PlayerPiece playerPiece in greenPlayerPiece)
            {
                playerPiece.StartBlinking();
            }
            
            return;
        }
        
        foreach (PlayerPiece playerPiece in greenPlayerPiece)
        {
            playerPiece.StopBlinking();
        }
    }

    public void StartStopBlinking(DiceColor color, bool shouldStart)
    {
        switch (color)
        {
            case DiceColor.Red:
                StartOrStopRedPieceBlinking(shouldStart);
                break;
            case DiceColor.Blue:
                StartOrStopBluePieceBlinking(shouldStart);
                break;
            case DiceColor.Yellow:
                StartOrStopYellowPieceBlinking(shouldStart);
                break;
            case DiceColor.Green:
                StartOrStopGreenPieceBlinking(shouldStart);
                break;
        }
    }
    
    private void Start()
    {
        // Register the event handler for receiving events
        PhotonNetwork.NetworkingClient.EventReceived += OnPhotonGameEventReceived;
    }

    private void OnDestroy()
    {
        // Unregister the event handler to avoid memory leaks
        PhotonNetwork.NetworkingClient.EventReceived -= OnPhotonGameEventReceived;
    }

    public void SetUpBoardAndTotalPlayers(int totalPlayers)
    {
        TotalPlayerCanPlay = totalPlayers;
        
        foreach (RollingDice rollingDice in manageRollingDice)
        {
            rollingDice.SetUpDiceRotation();
        }
    }

    public void AddPlayerToCurrentRoomPlayersList(DiceColor diceColor)
    {
        if (!currentBoardsPlayers.Contains(diceColor))
        {
            currentBoardsPlayers.Add(diceColor);
        }
    }

    public void RemovePlayerToCurrentRoomPlayersList(DiceColor diceColor)
    {
        if (currentBoardsPlayers.Contains(diceColor))
        {
            currentBoardsPlayers.Remove(diceColor);
        }
    }
    
    private void SetPieceId(PlayerPiece[] playerPieces)
    {
        for (int i = 0; i < playerPieces.Length; i++)
        {
            playerPieces[i].SetSelfId((byte)i);
        }
    }

    public void ChangeActiveDiceColor(DiceColor diceColor)
    {
        activeDiceColor = diceColor;
    }

    private Action actionToRunInRPC = null;

    public void RunMethodInRPC(Action action, RpcTarget rpcTarget = RpcTarget.AllBuffered, params object[] parameters)
    {
        photonView.RPC(nameof(RPC_MethodRunner), rpcTarget, parameters);
        actionToRunInRPC = action;
    }

    [PunRPC]
    private void RPC_MethodRunner()
    {
        actionToRunInRPC?.Invoke();
        actionToRunInRPC = null;
    }

    public void StartDiceBlinking(DiceColor diceColor)
    {
        if (DataManager.Instance.GameType != GameType.Multiplayer)
        {
            Debug.Log($"ActiveDiceColor: {diceColor}, OwnColor: {DataManager.Instance.OwnDiceColor}");
            foreach (var rollingDice in manageRollingDice)
            {
                if (rollingDice.SelfDiceColor == diceColor)
                {
                    rollingDice.gameObject.SetActive(true);
                    rollingDice.ActiveDiceAndStartBlinking();
                }
                else
                {
                    rollingDice.StopBlinkingAnimation();
                }
            }
            
            return;
        }
        
        foreach (var rollingDice in manageRollingDice)
        {
            if (rollingDice.SelfDiceColor == diceColor && diceColor == DataManager.Instance.OwnDiceColor)
            {
                rollingDice.ActiveDiceAndStartBlinking();
            }
            else if(rollingDice.SelfDiceColor == diceColor)
            {
                rollingDice.gameObject.SetActive(true);
                rollingDice.FirstTurn();
            }
            else
            {
                rollingDice.StopBlinkingAnimation();
            }
        }
    }
    
    public void AddPathPoint(PathPoint pathPoint_)
    {
        playerOnPathPointsList.Add(pathPoint_);
    }

    public void RemovePathPoint(PathPoint pathPoint_)
    {
        if (playerOnPathPointsList.Contains(pathPoint_))
        {
            playerOnPathPointsList.Remove(pathPoint_);
        }
        else
        {
            Debug.LogWarning("Path Point is not Found to be removed.");
        }
    }
    
    [PunRPC]
    public void RollingDiceManager()
    {
        Debug.Log("RollingDiceManager");
        if (transferDice)
        {
            if (numOfStepsToMove != 6)
            {
                ShiftDice();
            }

            canDiceRoll = true;
        }
        else if (selfDice)
        {
            selfDice = false;
            canDiceRoll = true;
            SelfRoll();
        }
    }

    public void SelfRoll()
    {
        Debug.Log("SelfRoll");
        if (TotalPlayerCanPlay == 1 && rolledDice == manageRollingDice[2])
        {
            Invoke(nameof(Rolled), 0.6f);
        }
    }

    void Rolled()
    {
        manageRollingDice[2].MouseRoll();
    }

    void ShiftDice()
    {
        int nextDice;

        if (TotalPlayerCanPlay == 1)
        {
            if (rolledDice == manageRollingDice[0])
            {
                UIManager.Instance.ChangeTurn(DiceColor.Yellow);
                
                manageRollingDice[0].gameObject.SetActive(false);
                //manageRollingDice[0].StopBlinkingAnimation();
                
                manageRollingDice[2].gameObject.SetActive(true);
                //manageRollingDice[2].StartBlinkingAnimation();
                
                PassOut(0);
                manageRollingDice[2].MouseRoll();

            }
            else
            {
                UIManager.Instance.ChangeTurn(DiceColor.Red);

                manageRollingDice[0].gameObject.SetActive(true);
                //manageRollingDice[0].StartBlinkingAnimation();
                
                manageRollingDice[2].gameObject.SetActive(false);
                //manageRollingDice[2].StopBlinkingAnimation();

                PassOut(2);
            }
        }
        //else if (TotalPlayerCanPlay == 2 && DataManager.Instance.GameType != GameType.Multiplayer)
        else if (TotalPlayerCanPlay == 2)
        {
            if (rolledDice == manageRollingDice[0])
            {
                UIManager.Instance.ChangeTurn(DiceColor.Yellow);
                
                manageRollingDice[0].gameObject.SetActive(false);
                manageRollingDice[2].gameObject.SetActive(true);
                PassOut(0);
            }
            else
            {
                UIManager.Instance.ChangeTurn(DiceColor.Red);
                
                manageRollingDice[0].gameObject.SetActive(true);
                manageRollingDice[2].gameObject.SetActive(false);

                PassOut(2);
            }
        }
        else if (TotalPlayerCanPlay == 3)
        {
            for (int i = 0; i < 3; i++)
            {
                if (i == 2)
                {
                    nextDice = 0;
                }
                else
                {
                    nextDice = i + 1;
                }
                
                i = PassOut(i);

                if (rolledDice == manageRollingDice[i])
                {
                    UIManager.Instance.ChangeTurn((DiceColor)nextDice);
                    
                    manageRollingDice[i].gameObject.SetActive(false);
                    manageRollingDice[nextDice].gameObject.SetActive(true);

                    // if (DataManager.Instance.GameType != GameType.Multiplayer)
                    // {
                    //     manageRollingDice[nextDice].gameObject.SetActive(true);
                    // }
                }
            }
        }
        else
        {
            for (int i = 0; i < 4; i++)
            {
                if (i == 3)
                {
                    nextDice = 0;
                }
                else
                {
                    nextDice = i + 1;
                }

                i = PassOut(i);

                if (rolledDice == manageRollingDice[i])
                {
                    UIManager.Instance.ChangeTurn((DiceColor)nextDice);
                    
                    manageRollingDice[i].gameObject.SetActive(false);
                    manageRollingDice[nextDice].gameObject.SetActive(true);

                    // if (DataManager.Instance.GameType != GameType.Multiplayer)
                    // {
                    //     manageRollingDice[nextDice].gameObject.SetActive(true);
                    // }
                }
            }
        }
    }
    public void UpdatePlayerMovement(int activeDiceIndex)
    {
        // Reset all movement permissions to false
        blueCanMove = redCanMove = greenCanMove = yellowCanMove = false;

        // Enable movement based on active dice
        switch (activeDiceIndex)
        {
            case 0: // Blue Dice
                blueCanMove = true;
                break;
            case 1: // Red Dice
                redCanMove = true;
                break;
            case 2: // Green Dice
                greenCanMove = true;
                break;
            case 3: // Yellow Dice
                yellowCanMove = true;
                break;
        }
    }
    int PassOut(int i)
    {
        if (i == 0) 
        { 
            if (GameManager.Instance.blueCompletePlayer == 4) 
            { 
                return (i + 1);
            } 
        }
        else if (i == 1) 
        { 
            if (GameManager.Instance.redCompletePlayer == 4) 
            {
                return (i + 1);
            }
        }
        else if (i == 2) 
        { 
            if (GameManager.Instance.greenCompletePlayer == 4) 
            {
                return (i + 1);
            }
        }
        else if (i == 3) 
        { 
            if (GameManager.Instance.yellowCompletePlayer == 4) 
            {
                return (i + 1);
            }
        }

        return i;
    }

    public bool IsMyTurn()
    {
        return DataManager.Instance.OwnDiceColor == DataManager.Instance.ActiveDiceColor;
    }

    // Method to check if a player has won the game
    public void CheckForWinner()
    {
        if (blueCompletePlayer == 4)
        {
            if(DataManager.Instance.GameType == GameType.Single)
                EndGame(DiceColor.Blue);
            else
                RaiseGameOverCustomEvent(DiceColor.Blue);
        }
        else if (redCompletePlayer == 4)
        {
            if(DataManager.Instance.GameType == GameType.Single)
                EndGame(DiceColor.Red);
            else
                RaiseGameOverCustomEvent (DiceColor.Red);
        }
        else if (greenCompletePlayer == 4)
        {
            if (DataManager.Instance.GameType == GameType.Single)
                EndGame(DiceColor.Green);
            else
                RaiseGameOverCustomEvent(DiceColor.Green);
        }
        else if (yellowCompletePlayer == 4)
        {
            if (DataManager.Instance.GameType == GameType.Single)
                EndGame(DiceColor.Yellow);
            else
                RaiseGameOverCustomEvent(DiceColor.Yellow);
        }
    }

    public void RaiseGameOverCustomEvent(DiceColor winingDiceColor)
    {
        // Event data you want to send (it can be any serializable object)
        object content = winingDiceColor;

        // Define who will receive the event (all players in the room)
        RaiseEventOptions raiseEventOptions = new RaiseEventOptions
        {
            Receivers = ReceiverGroup.All // You can use ReceiverGroup.MasterClient, Others, etc.
        };

        // Send options (whether to send reliably or not)
        SendOptions sendOptions = new SendOptions
        {
            Reliability = true // If true, event is sent reliably
        };

        // Raise the event
        PhotonNetwork.RaiseEvent(GAME_OVER_EVENT_CODE, content, raiseEventOptions, sendOptions);
    }

    private void OnPhotonGameEventReceived(EventData photonEvent)
    {
        // Check if the event code matches the custom event
        if (photonEvent.Code == GAME_OVER_EVENT_CODE)
        {
            // Get the data from the event (it will match the type of data you sent)
            object eventData = photonEvent.CustomData;

            // Cast it to a string (in this case, because we sent a string)
            DiceColor winingDiceColor = (DiceColor) eventData;

            // Handle the received event (you can do anything here, for example, log the message)
            Debug.Log($"Received custom event message: {winingDiceColor}");

            EndGame(winingDiceColor);
        }
        else if(photonEvent.Code == CURRENT_TURN_EVENT_CODE)
        {
            // Get the data from the event (it will match the type of data you sent)
            object eventData = photonEvent.CustomData;

            // Cast it to a string (in this case, because we sent a string)
            DiceColor activeDiceColor = (DiceColor) eventData;

            // Handle the received event (you can do anything here, for example, log the message)
            Debug.Log($"Received custom event message of Current Turn: {activeDiceColor}");
            DataManager.Instance.SetActiveDiceColor(activeDiceColor);
            UIManager.Instance.ChangeTurnForMultiplayer(activeDiceColor);
        }
    }

    public void RaiseTurnChangeEvent(DiceColor diceColor)
    {
        // Event data you want to send (it can be any serializable object)
        object content = diceColor;

        // Define who will receive the event (all players in the room)
        RaiseEventOptions raiseEventOptions = new RaiseEventOptions
        {
            Receivers = ReceiverGroup.All // You can use ReceiverGroup.MasterClient, Others, etc.
        };

        // Send options (whether to send reliably or not)
        SendOptions sendOptions = new SendOptions
        {
            Reliability = true // If true, event is sent reliably
        };

        // Raise the event
        PhotonNetwork.RaiseEvent(CURRENT_TURN_EVENT_CODE, content, raiseEventOptions, sendOptions);
    }

    // Method to end the game and declare the winner
    public void EndGame(DiceColor winningColor)
    {
        canMove = false;
        canDiceRoll = false;
        Debug.Log(winningColor + " has won the game!");

        // Optional: Play a victory sound or show a victory screen
        //audioSource.PlayOneShot(victorySound);

        // Optional: Transition to a victory screen, restart the game, or return to the main menu
        //ShowVictoryScreen(winningColor);
        // SceneManager.LoadScene("MainMenu");
        DataManager.Instance.SetCurrentGameState(GameState.Finished);
        UIManager.Instance.OnGameFinished(winningColor);


        //if(DataManager.Instance.CurrentRoomType == RoomType.AI || DataManager.Instance.CurrentRoomType == RoomType.Free)
        //    UIManager.Instance.OnGameFinished(winningColor);
        //else
        //{
        //    endgame.SetActive(true);
        //    wontext.text = winningColor + " has won the game!";
        //}
    }

    // Example method where you should call CheckForWinner after a token reaches home
    public void MovePlayerToken(PlayerPiece player)
    {
        // Your existing logic for moving the player token

        // After the move, check if the player has won
        CheckForWinner();
    }

    public void RestartGamne()
    {
       UIManager.Instance.BackToMainMenu();
    }

    #region Debug
    [Space(30), Header("Debug Region")]
    [SerializeField] private int Debug_DesiredNum;
    [SerializeField] private bool isDebuggingOn;

    public bool IsDebuggingOn() => isDebuggingOn;

    public int Debug_GetDesiredNum() 
    {
        if(Debug_DesiredNum >= 6)
            Debug_DesiredNum = 5;
        else if(Debug_DesiredNum < 0)
            Debug_DesiredNum = 0;
        
        return Debug_DesiredNum;
    }
    #endregion Debug

}
