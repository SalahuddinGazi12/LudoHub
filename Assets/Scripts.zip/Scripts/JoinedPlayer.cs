using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class JoinedPlayer : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI selfNameText;
    public DiceColor SelfDiceColor { get; private set; }

    public void SetJoinedPlayerInfo(string playerName, DiceColor diceColor)
    {
        selfNameText.text = Helper.GetPascalCaseString(playerName);
        SelfDiceColor = diceColor;
        gameObject.name = $"JoinedPlayer_{diceColor}";
        gameObject.SetActive(true);
        
    }
}
