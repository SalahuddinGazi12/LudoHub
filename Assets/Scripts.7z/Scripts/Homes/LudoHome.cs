using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LudoHome : MonoBehaviour
{
    public RollingDice rollingDice;
    public PlayerPiece[] playerPieces;
}
