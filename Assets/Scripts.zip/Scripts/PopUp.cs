using TMPro;
using UnityEngine;

public class PopUp : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI messageTxt;


    public void ShowMessagePanel(string message)
    {
        messageTxt.text = message;
        gameObject.SetActive(true);
    }

    public void CloseMessagePanel()
    {
        gameObject.SetActive(false);
    }
    
}
