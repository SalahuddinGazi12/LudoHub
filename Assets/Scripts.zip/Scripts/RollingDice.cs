using System;
using System.Collections;
using UnityEngine;
using Random = UnityEngine.Random;
using Photon.Pun;
using  UnityEngine.UI;

public class RollingDice : MonoBehaviour
{
    [SerializeField] int numberGot;
    [SerializeField] GameObject rollingDiceAnim;
    [SerializeField] GameObject profileGameObject;
    [SerializeField] GameObject castDiceGameObject;
    [SerializeField] SpriteRenderer numberedSpriteHolder;
    [SerializeField] Sprite[] numberedSprites;
    [SerializeField] private Image powerBarFillImg;
    [SerializeField] private float fillSpeed;
    [SerializeField] private GameObject blinkingSprite;
    [SerializeField] private Slider turnTimerSlider;
    [SerializeField] private Image selfAvatarSprite;
    [SerializeField] private Transform normalRotAndPos;
    [SerializeField] private Transform sideRotAndPos;
    [SerializeField] private CircleCollider2D selfCollider;
    [SerializeField] private Transform parentTransform;
    [SerializeField] private Transform z_90RotationTransform;
    [SerializeField] private Transform z_180RotationTransform;
    [SerializeField] private Transform y_180RotationTransform;
    private float blinkingWaitTime = 0.3f;
    Coroutine generateRandNumOnDice_Coroutine;
    public int outPieces;
    public PathObjectsParent pathParent;
    PlayerPiece[] currentPlayerPieces;
    PathPoint[] pathPointToMoveOn_;
    Coroutine moveSteps_Coroutine;
    PlayerPiece outPlayerPiece;

    public Dice DiceSound;
    public DiceColor SelfDiceColor => diceColor;
    public DiceColor diceColor;
    private PhotonView photonView;
    private bool onMouseDown;
    private Coroutine powerBarFillCoroutine;
    private Coroutine blinkingCoroutine;
    private Coroutine timerCoroutine;
    private int timeSinceTurnTimerStarted;
    [SerializeField] private int turnIgnored;

    private void Awake()
    {
        pathParent = FindAnyObjectByType<PathObjectsParent>();

        diceColor = GetDiceColor(gameObject);

        photonView = GetComponent<PhotonView>();
        
        InitializeTurnSlider();
    }

    public void SetSelfAvatar(Sprite avatarSprite)
    {
        selfAvatarSprite.sprite = avatarSprite;
    }
    
    public void SetUpDiceRotation()
    {
        if (DataManager.Instance.GameType != GameType.Multiplayer)
        {
            switch (SelfDiceColor)
            {
                case DiceColor.Blue:
                    transform.localEulerAngles = new Vector3(180f, 0f, 0f);
                    break;
                case DiceColor.Yellow:
                    transform.localEulerAngles = new Vector3(0, 0, 180);
                    break;

                case DiceColor.Green:
                    transform.localEulerAngles = new Vector3(0f, 180f, 0f);
                    break;

                default:
                    transform.localEulerAngles = Vector3.zero;
                    break;
            }
            return;
        }

        switch (DataManager.Instance.LocalRotation)
        {
            case LocalRotation.Y180:
                parentTransform.localEulerAngles = new Vector3(0f, -180f, 0f);
                transform.localEulerAngles = y_180RotationTransform.localEulerAngles;
                transform.localPosition = y_180RotationTransform.localPosition;
                break;

            case LocalRotation.Z90:
                parentTransform.localEulerAngles = new Vector3(0f, 0f, -90f);
                transform.localEulerAngles = z_90RotationTransform.localEulerAngles;
                transform.localPosition = z_90RotationTransform.localPosition;
                break;

            case LocalRotation.Z180:
                parentTransform.localEulerAngles = new Vector3(0f, 0f, -180f);
                transform.localEulerAngles = z_180RotationTransform.localEulerAngles;
                transform.localPosition = z_180RotationTransform.localPosition;
                break;
        }
    }

    private void ChangeTurnSliderAnchorPosition(AnchorPos anchorPos)
    {
        RectTransform rectTransform = turnTimerSlider.GetComponent<RectTransform>();

        if (rectTransform == null)
            return;

        switch (anchorPos)
        {
            case AnchorPos.LeftBottom:
                rectTransform.anchorMin = new Vector2(0, 0);
                rectTransform.anchorMax = new Vector2(0, 0);
                rectTransform.pivot = new Vector2(0, 0);  // Pivot at bottom-left
                rectTransform.anchoredPosition = Vector2.zero;
                break;

            case AnchorPos.LeftTop:
                // Set anchors to the top-left corner
                rectTransform.anchorMin = new Vector2(0, 1);  // Bottom-left of the parent
                rectTransform.anchorMax = new Vector2(0, 1);  // Top-left of the parent

                // Set pivot to the top-left corner
                rectTransform.pivot = new Vector2(0, 1);
                // Set anchored position (0, 0) to keep it at the top-left relative to the parent
                rectTransform.anchoredPosition = Vector2.zero;
                break;

            case AnchorPos.RightTop:
                rectTransform.anchorMin = new Vector2(1, 1);
                rectTransform.anchorMax = new Vector2(1, 1);
                rectTransform.pivot = new Vector2(1, 1);  // Pivot at top-right
                rectTransform.anchoredPosition = Vector2.zero;
                break;

            case AnchorPos.RightBottom:
                // Set anchors to the bottom-left corner
                rectTransform.anchorMin = new Vector2(0, 0);  // Bottom-left of the parent
                rectTransform.anchorMax = new Vector2(0, 0);  // Bottom-left of the parent

                // Set pivot to the bottom-left corner
                rectTransform.pivot = new Vector2(0, 0);
                // Set anchored position to (0, 0) to keep it at the bottom-left relative to the parent
                rectTransform.anchoredPosition = Vector2.zero;
                break;
        }
    }

    private DiceColor GetDiceColor(GameObject targetGameObject)
    {
        // Loop through the enum values
        foreach (DiceColor color in Enum.GetValues(typeof(DiceColor)))
        {
            if (targetGameObject.name.Contains(color.ToString()))
            {
                return color;
            }
        }

        // Return Unknown if no match is found
        return DiceColor.Unknown;
    }

    public void OnMouseDown()
    {
        if(DataManager.Instance.GameType == GameType.Multiplayer)
        {
            if (!GameManager.Instance.IsMyTurn())
                return;
        }
        
        //GenerateNumberAndRollTheDice();
        StartPowerBarFillEffect();
    }
    
    public void OnMouseUp()
    {
        if (DataManager.Instance.GameType == GameType.Multiplayer)
        {
            if (!GameManager.Instance.IsMyTurn())
                return;
        }

        StopTimer();
        StopPowerBarFillEffect();
    }

    private void OnDisable()
    {
        HidePowerBar();
        GameManager.Instance.diceAnimationController.HideDice();
        ResetDice();
        ResetAndDisableTurnTimer();
        StopTimerCoroutine();
        StopTimer();
        //CancelSelfPowerBarFill();
        //StopBlinkingAnimation();
    }

    public void FirstTurn()
    {
        castDiceGameObject.SetActive(true);
        selfCollider.enabled = false;
        turnTimerSlider.gameObject.SetActive(true);
    }
    
    private void DiceNumberSpriteHandlerForRpc()
    {
        turnTimerSlider.gameObject.SetActive(true);
        
        if (DataManager.Instance.OwnDiceColor == DataManager.Instance.ActiveDiceColor)
        {
            castDiceGameObject.SetActive(true);
            selfCollider.enabled = true;
            StartTurnTimerInvokation();
            return;
        }
        
        castDiceGameObject.SetActive(false);
        powerBarFillImg.transform.parent.gameObject.SetActive(false);
        selfCollider.enabled = false;
    }

    private void ResetDice()
    {
        castDiceGameObject.SetActive(false);
        powerBarFillImg.transform.parent.gameObject.SetActive(true);
        selfCollider.enabled = false;
    }

    public void ActiveDiceAndStartBlinking()
    {
        InitializeTurnSlider();
        StartBlinkingAnimation();

        if (DataManager.Instance.GameType == GameType.Multiplayer)
        {
            TurnChangeHandler();
        }
        else
        {
            castDiceGameObject.SetActive(true);
            selfCollider.enabled = true;
            turnTimerSlider.gameObject.SetActive(false);
        }
        
    }

    private void TurnChangeHandler()
    {
        photonView.RPC(nameof(TurnChangeHandlerRPC), RpcTarget.Others);
        
        TurnChangeHandlerRPC();
    }

    [PunRPC]
    private void TurnChangeHandlerRPC()
    {
        DiceNumberSpriteHandlerForRpc();
    }

    private void StartTurnTimerInvokation()
    {
        turnTimerSlider.value = turnTimerSlider.maxValue;
        timeSinceTurnTimerStarted = (int) turnTimerSlider.maxValue;
        turnTimerSlider.gameObject.SetActive(true);

        timerCoroutine ??= StartCoroutine(TimerCoroutine());
       // StartTurnTimer();
    }

    private void StopTimer()
    {
        if(DataManager.Instance.GameType == GameType.Multiplayer)
            photonView.RPC(nameof(StopTimerRPC), RpcTarget.AllBuffered);
    }

    [PunRPC]
    private void StopTimerRPC()
    {
        if (timerCoroutine == null) 
            return;
        
        StopCoroutine(timerCoroutine);
        turnTimerSlider.value = turnTimerSlider.maxValue;
        turnTimerSlider.gameObject.SetActive(false);
    }

    private IEnumerator TimerCoroutine()
    {
        var waitForTime = new WaitForSeconds(1);

        while (timeSinceTurnTimerStarted > 0)
        { 
            photonView.RPC(nameof(UpdateTurnSliderValue), RpcTarget.Others, timeSinceTurnTimerStarted);
            UpdateTurnSliderValue(timeSinceTurnTimerStarted);
            yield return waitForTime;
            timeSinceTurnTimerStarted -= 1;
        }
        
        Debug.Log("Turn Time is over!");
        timeSinceTurnTimerStarted = (int) turnTimerSlider.maxValue;
        timerCoroutine = null;
        Debug.Log("From Before Shift Dice");
        ShiftDice();
    }

    public void ShiftDice()
    {
        //GameManager.Instance.RunMethodInRPC(RollingDiceManager);
        if(PhotonNetwork.CurrentRoom.PlayerCount > 1)
            photonView.RPC(nameof(RollingDiceManagerRPC), RpcTarget.AllBuffered);
        Debug.Log("From After Shift Dice");
        turnIgnored++;
    }

    private void StopTimerCoroutine()
    {
        if (timerCoroutine != null)
        {
            StopCoroutine(timerCoroutine);
            timerCoroutine = null;
        }
    }
    

    [PunRPC]
    private void UpdateTurnSliderValue(int value)
    {
        turnTimerSlider.value = value;
    }

    private void InitializeTurnSlider()
    {
        turnTimerSlider.minValue = 0;
        turnTimerSlider.maxValue = DataManager.Instance.MaxTurnTime;
        turnTimerSlider.value = turnTimerSlider.maxValue;
        
        turnTimerSlider.gameObject.SetActive(true);
    }

    private void ResetAndDisableTurnTimer()
    {
        turnTimerSlider.value = 0;
        turnTimerSlider.gameObject.SetActive(false);
    }
    
    public void DisableAndStopBlinking()
    {
        StopBlinkingAnimation();
        gameObject.SetActive(false);
    }

    public void StartBlinkingAnimation()
    {
        gameObject.SetActive(true);
        Debug.Log($"Active Dice: {DataManager.Instance.ActiveDiceColor}, OwnDiceColor: {DataManager.Instance.OwnDiceColor}");
        blinkingCoroutine ??= StartCoroutine(BlinkingAnimation());
        GameManager.Instance.StartStopBlinking(SelfDiceColor, true);
    }

    public void StopBlinkingAnimation()
    {
        if(blinkingCoroutine == null)
            return;
        
        StopCoroutine(BlinkingAnimation());
        blinkingCoroutine = null;
        blinkingSprite.gameObject.SetActive(false);
        GameManager.Instance.StartStopBlinking(SelfDiceColor, false);
    }

    private IEnumerator BlinkingAnimation()
    {
        var waitTime = new WaitForSeconds(blinkingWaitTime);
        
        while (gameObject.activeSelf && DataManager.Instance.CurrentGameState != GameState.Finished)
        {
            blinkingSprite.gameObject.SetActive(true);
            yield return waitTime;
            blinkingSprite.gameObject.SetActive(false);
            yield return waitTime;
        }
    }
    
    private void ShowPowerBar() => powerBarFillImg.transform.parent.gameObject.SetActive(true);
    private void HidePowerBar() => powerBarFillImg.transform.parent.gameObject.SetActive(false);

    private void StartPowerBarFillEffect()
    {
        onMouseDown = true;

        // if (DataManager.Instance.GameType == GameType.Multiplayer)
        // {
        //     photonView.RPC(nameof(StartPowerBarFillEffectRPC), RpcTarget.Others);
        //     //return;
        // }

        StartPowerBarFillEffectRPC();
    }

    [PunRPC]
    private void StartPowerBarFillEffectRPC()
    {
        if (powerBarFillCoroutine != null)
        {
            return;
        }

        onMouseDown = true;
        powerBarFillCoroutine = StartCoroutine(PowerBarFillEffect());
    }


    private void StopPowerBarFillEffect()
    {
        onMouseDown = false;
        int randomNum = GetRandomNumber();

        if (DataManager.Instance.GameType == GameType.Multiplayer)
        {
            photonView.RPC(nameof(StopPowerBarFillEffectRPC), RpcTarget.Others, randomNum);
        }

        StopPowerBarFillEffectRPC(randomNum);
    }

    [PunRPC]
    private void StopPowerBarFillEffectRPC(int randomNum)
    {
        if (powerBarFillCoroutine != null)
        {
            StopCoroutine(powerBarFillCoroutine);
        }
        
        onMouseDown = false;
        powerBarFillCoroutine = null;
        powerBarFillImg.fillAmount = 0;
        GenerateNumberAndRollTheDice(randomNum);
    }

    private IEnumerator PowerBarFillEffect()
    {
        float directionIndicator = 0;

        powerBarFillImg.fillAmount = directionIndicator;
        ShowPowerBar();

        while (onMouseDown)
        {
            if (directionIndicator == 0)
            {
                powerBarFillImg.fillAmount += fillSpeed * Time.deltaTime;
                if (powerBarFillImg.fillAmount >= 1)
                    directionIndicator = 1;
            }
            else
            {
                powerBarFillImg.fillAmount -= fillSpeed * Time.deltaTime;
                if (powerBarFillImg.fillAmount <= 0)
                    directionIndicator = 0;
            }

            yield return null;
        }
    }

    private int GetRandomNumber()
    {
        int randomNum = Random.Range(0, 6);

        if (GameManager.Instance.IsDebuggingOn())
            randomNum = GameManager.Instance.Debug_GetDesiredNum();

        return randomNum;
    }


    public void MouseRoll()
    {
        GenerateNumberAndRollTheDice(GetRandomNumber());
        //if (DataManager.Instance.GameType == GameType.Multiplayer)
        //{
        //    GenerateNumberAndRollTheDice();
        //    return;
        //}

        //int numberGot = Random.Range(4, 6);

        //if (GameManager.Instance.IsDebuggingOn())
        //    numberGot = GameManager.Instance.Debug_GetDesiredNum();

        //generateRandNumOnDice_Coroutine = StartCoroutine(GenerateRandomNumberOnDice_Enum(numberGot));
    }

    private void GenerateNumberAndRollTheDice(int generatedNum)
    {
        if (DataManager.Instance.GameType == GameType.Multiplayer)
        {
            photonView.RPC(nameof(RollTheDice), RpcTarget.Others, generatedNum);
        }

        RollTheDice(generatedNum);
    }

    [PunRPC]
    public void RollTheDice(int generatedNum)
    {
        generateRandNumOnDice_Coroutine = StartCoroutine(GenerateRandomNumberOnDice_Enum(generatedNum));
    }

    IEnumerator GenerateRandomNumberOnDice_Enum(int generatedNum)
    {
        DiceSound.PlaySound();
        GameManager.Instance.transferDice = false;
        
        yield return new WaitForEndOfFrame();

        if (GameManager.Instance.canDiceRoll)
        {
            GameManager.Instance.canDiceRoll = false;
            //numberedSpriteHolder.gameObject.SetActive(false);
            //rollingDiceAnim.SetActive(true);

            numberGot = generatedNum;
            GameManager.Instance.diceAnimationController.AnimateAndShowGotNumber(generatedNum, 0.5f);
            yield return new WaitForSeconds(0.7f);

            //numberGot = Random.Range(0, 6);
            //numberedSpriteHolder.sprite = numberedSprites[numberGot];
            numberGot += 1;

            GameManager.Instance.numOfStepsToMove = numberGot;
            GameManager.Instance.rolledDice = this;

            //numberedSpriteHolder.gameObject.SetActive(true);
            //rollingDiceAnim.SetActive(false);

            yield return new WaitForEndOfFrame();


            int numGot = GameManager.Instance.numOfStepsToMove;

            if (PlayerCannotMove())
            {
                Debug.Log($"PlayerCannotMove, NumberGot: {numberGot}");
                yield return new WaitForSeconds(0.5f);
                if (numGot != 6)
                {
                    GameManager.Instance.transferDice = true;
                }
                else
                {
                    GameManager.Instance.selfDice = true;
                }
            }
            else
            {
                Debug.Log("PlayerCanMove Else");

                if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[0])
                {
                    outPieces = GameManager.Instance.redOutPlayers;
                }
                else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[1])
                {
                    outPieces = GameManager.Instance.blueOutPlayers;
                }
                else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[2])
                {
                    outPieces = GameManager.Instance.yellowOutPlayers;
                }
                else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[3])
                {
                    outPieces = GameManager.Instance.greenOutPlayers;
                }

                if (outPieces == 0 && numGot != 6)
                {
                    Debug.Log("Transferring Dice");
                    yield return new WaitForSeconds(0.5f);
                    GameManager.Instance.transferDice = true;
                }
                else
                {
                    if (outPieces == 0 && numGot == 6)
                    {
                        Debug.Log("Outing opening piece");
                        MakePlayerReadyToMove(0);
                    }
                    else if (outPieces == 1 && numGot != 6 && GameManager.Instance.canMove)
                    {
                        int playerPiecePosition = CheckOutPlayer();

                        if (playerPiecePosition >= 0)
                        {
                            Debug.Log($"playerPiecePosition >= 0, PlayerPiecePosition: {playerPiecePosition}");
                            GameManager.Instance.canMove = false;
                            moveSteps_Coroutine = StartCoroutine(MoveSteps_Enum(playerPiecePosition));
                        }
                        else
                        {
                            yield return new WaitForSeconds(0.5f);

                            if (numberGot != 6)
                            {
                                GameManager.Instance.transferDice = true;
                            }
                            else
                            {
                                Debug.Log($"Else and numberGot is not 6, NumberGot: {numberGot}");
                                GameManager.Instance.selfDice = true;
                            }
                        }
                    }
                    //For AI
                    else if (GameManager.Instance.TotalPlayerCanPlay == 1 && GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[2])
                    {
                        Debug.Log("AI");

                        if (numberGot == 6 && outPieces < 4)
                        {
                            MakePlayerReadyToMove(outPlayerToMove());
                        }
                        else
                        {
                            int playerPiecePosition = CheckOutPlayer();
                            if (playerPiecePosition >= 0)
                            {
                                GameManager.Instance.canMove = false;
                                moveSteps_Coroutine = StartCoroutine(MoveSteps_Enum(playerPiecePosition));

                            }
                            else
                            {
                                yield return new WaitForSeconds(0.5f);
                                if (numGot != 6)
                                {
                                    GameManager.Instance.transferDice = true;
                                }
                                else
                                {
                                    GameManager.Instance.selfDice = true;

                                }
                            }

                        }
                    }
                    else
                    {
                        if (CheckOutPlayer() < 0)
                        {
                            yield return new WaitForSeconds(0.5f);
                            if (numGot != 6)
                            {
                                GameManager.Instance.transferDice = true;
                            }
                            else
                            {
                                GameManager.Instance.selfDice = true;

                            }
                            Debug.Log($"CheckOutPlayer() < 0, NumberGot: {numberGot}");
                        }
                    }
                }  
            }
           
            if(DataManager.Instance.GameType == GameType.Multiplayer)
            {
                photonView.RPC(nameof(RollingDiceManager), RpcTarget.AllBuffered);
                //GameManager.Instance.RunMethodInRPC(RollingDiceManager);
            }
            else
            {
                RollingDiceManager();
            }
        }
    }

    [PunRPC]
    private void RollingDiceManager()
    {
        GameManager.Instance.RollingDiceManager();

        if (generateRandNumOnDice_Coroutine != null)
        {
            //StopCoroutine(GenerateRandomNumberOnDice_Enum());
            StopCoroutine(generateRandNumOnDice_Coroutine);
        }
    }
    
    [PunRPC]
    private void RollingDiceManagerRPC()
    {
        Debug.Log("From RollingDiceManagerRPC");
        GameManager.Instance.transferDice = true;
        GameManager.Instance.rolledDice = this;
        
        GameManager.Instance.RollingDiceManager();

        if (generateRandNumOnDice_Coroutine != null)
        {
            //StopCoroutine(GenerateRandomNumberOnDice_Enum());
            StopCoroutine(generateRandNumOnDice_Coroutine);
        }
    }

    int outPlayerToMove()
    {
        for (int i = 0; i < 4; i++) 
        {
            if(!GameManager.Instance.yellowPlayerPiece[i].isReady)
            {
                return i;
            }
        }
        return 0;
    }

    int CheckOutPlayer()
    {
        switch (diceColor)
        {
            case DiceColor.Red:
                currentPlayerPieces = GameManager.Instance.redPlayerPiece;
                pathPointToMoveOn_ = pathParent.redPathPoints;
                break;

            case DiceColor.Blue:
                currentPlayerPieces = GameManager.Instance.bluePlayerPiece;
                pathPointToMoveOn_ = pathParent.bluePathPoints;
                break;
            case DiceColor.Yellow:
                currentPlayerPieces = GameManager.Instance.yellowPlayerPiece;
                pathPointToMoveOn_ = pathParent.yellowPathPoints;
                break;
            case DiceColor.Green:
                currentPlayerPieces = GameManager.Instance.greenPlayerPiece;
                pathPointToMoveOn_ = pathParent.greenPathPoints;
                break;
        }
        for (int i = 0; i < currentPlayerPieces.Length; i++)
        {
            if (currentPlayerPieces[i].isReady && isPathPointsAvailableToMove(GameManager.Instance.numOfStepsToMove, currentPlayerPieces[i].numberOfStepsAlreadyMoved, pathPointToMoveOn_))
            {
                //Debug.Log($"#currentPlayerPiecesName: {currentPlayerPieces[i]}, index: {i}, Length: {currentPlayerPieces.Length}, Returning False!", currentPlayerPieces[i].gameObject);
                return i;
            }
        }

        return -1;
    }

    public bool PlayerCannotMove()
    {
        if (outPieces > 0)
        {
            bool cannotMove = false;

            if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[0])
            {
                currentPlayerPieces = GameManager.Instance.redPlayerPiece;
                pathPointToMoveOn_ = pathParent.redPathPoints;
            }
            else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[1])
            {
                currentPlayerPieces = GameManager.Instance.bluePlayerPiece;
                pathPointToMoveOn_ = pathParent.bluePathPoints;
            }
            else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[2])
            {
                currentPlayerPieces = GameManager.Instance.yellowPlayerPiece;
                pathPointToMoveOn_ = pathParent.yellowPathPoints;
            }
            else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[3])
            {
                currentPlayerPieces = GameManager.Instance.greenPlayerPiece;
                pathPointToMoveOn_ = pathParent.greenPathPoints;
            }

            Debug.Log($"outPieces, {outPieces}, currentPlayerPieces.Length: {currentPlayerPieces.Length}");

            for (int i = 0; i < currentPlayerPieces.Length; i++)
            {
                if (currentPlayerPieces[i].isReady)
                {
                    //Debug.Log($"#Name: {currentPlayerPieces[i].name}, isReady: {currentPlayerPieces[i].isReady}, CannotMove: {cannotMove}", currentPlayerPieces[i].gameObject);
                    if (isPathPointsAvailableToMove(GameManager.Instance.numOfStepsToMove, currentPlayerPieces[i].numberOfStepsAlreadyMoved, pathPointToMoveOn_))
                    {
                        return false;
                    }
                }
                else
                {
                    if (!cannotMove)
                    {
                        cannotMove = true;
                    }
                }
            }
            
            if (cannotMove)
            {
                return true;
            }
        }

        return false;
    }
    bool isPathPointsAvailableToMove(int numOfStepsToMove_, int numOfStepsAlreadyMoved_, PathPoint[] pathPointsToMoveOn_)
    {
        int leftNumOfPathPoints = pathPointsToMoveOn_.Length - numOfStepsAlreadyMoved_;
        if (leftNumOfPathPoints >= numOfStepsToMove_)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void MakePlayerReadyToMove(int outPlayer)
    {
        switch (diceColor)
        {
            case DiceColor.Red:
                outPlayerPiece = GameManager.Instance.redPlayerPiece[outPlayer];
                pathPointToMoveOn_ = pathParent.redPathPoints;
                GameManager.Instance.redOutPlayers++;
                break;
            
            case DiceColor.Blue:
                outPlayerPiece = GameManager.Instance.bluePlayerPiece[outPlayer];
                pathPointToMoveOn_ = pathParent.bluePathPoints;
                GameManager.Instance.blueOutPlayers++;
                break;

            case DiceColor.Yellow:
                outPlayerPiece = GameManager.Instance.yellowPlayerPiece[outPlayer];
                pathPointToMoveOn_ = pathParent.yellowPathPoints;
                GameManager.Instance.yellowOutPlayers++;
                break;
            
            case DiceColor.Green:
                outPlayerPiece = GameManager.Instance.greenPlayerPiece[outPlayer];
                pathPointToMoveOn_ = pathParent.greenPathPoints;
                GameManager.Instance.greenOutPlayers++;
                break;
        }

        // The rest of your existing MakePlayerReadyToMove logic...
        outPlayerPiece.isReady = true;
        outPlayerPiece.transform.position = pathPointToMoveOn_[0].transform.position;
        outPlayerPiece.numberOfStepsAlreadyMoved = 1;

        outPlayerPiece.previousPathPoint = pathPointToMoveOn_[0];
        outPlayerPiece.currentPathPoint = pathPointToMoveOn_[0];
        outPlayerPiece.currentPathPoint.AddPlayerPiece(outPlayerPiece);

        GameManager.Instance.RemovePathPoint(outPlayerPiece.previousPathPoint);
        GameManager.Instance.AddPathPoint(outPlayerPiece.currentPathPoint);
        GameManager.Instance.canDiceRoll = true;
        GameManager.Instance.selfDice = true;
        GameManager.Instance.transferDice = false;
        GameManager.Instance.numOfStepsToMove = 0;
        GameManager.Instance.SelfRoll();

    }
    IEnumerator MoveSteps_Enum(int movePlayer)
    {
        if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[0])
        {
            outPlayerPiece = GameManager.Instance.redPlayerPiece[movePlayer];
            pathPointToMoveOn_ = pathParent.redPathPoints;
            
        }
        else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[1])
        {
            outPlayerPiece = GameManager.Instance.bluePlayerPiece[movePlayer];
            pathPointToMoveOn_ = pathParent.bluePathPoints;
            
        }
        else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[2])
        {
            outPlayerPiece = GameManager.Instance.yellowPlayerPiece[movePlayer];
            pathPointToMoveOn_ = pathParent.yellowPathPoints;
           
        }
        else if (GameManager.Instance.rolledDice == GameManager.Instance.manageRollingDice[3])
        {
            outPlayerPiece = GameManager.Instance.greenPlayerPiece[movePlayer];
            pathPointToMoveOn_ = pathParent.greenPathPoints;
           
        }

        GameManager.Instance.transferDice = false;
        yield return new WaitForSeconds(0.25f);
        int numOfStepsToMove = GameManager.Instance.numOfStepsToMove;

      //  if (GameManager.gm.canMove)
       // {
            outPlayerPiece.currentPathPoint.RescaleAndRepositionAllPlayerPieces();
        
            for (int i = outPlayerPiece.numberOfStepsAlreadyMoved; i < (outPlayerPiece.numberOfStepsAlreadyMoved + numOfStepsToMove); i++)
            {
                if (isPathPointsAvailableToMove(numOfStepsToMove, outPlayerPiece.numberOfStepsAlreadyMoved, pathPointToMoveOn_))
                {
                    outPlayerPiece.transform.position = pathPointToMoveOn_[i].transform.position;

                    yield return new WaitForSeconds(0.25f);
                }
            }
        //}
        if (isPathPointsAvailableToMove(numOfStepsToMove, outPlayerPiece.numberOfStepsAlreadyMoved, pathPointToMoveOn_))
        {

            outPlayerPiece.numberOfStepsAlreadyMoved += numOfStepsToMove;

            GameManager.Instance.RemovePathPoint(outPlayerPiece.previousPathPoint);
            outPlayerPiece.previousPathPoint.RemovePlayerPiece(outPlayerPiece);
            outPlayerPiece.currentPathPoint = pathPointToMoveOn_[outPlayerPiece.numberOfStepsAlreadyMoved - 1];

            if (outPlayerPiece.currentPathPoint.AddPlayerPiece(outPlayerPiece))
            {
                if (outPlayerPiece.numberOfStepsAlreadyMoved == 57)
                {
                    GameManager.Instance.selfDice = true;

                }
                else
                {
                    if (GameManager.Instance.numOfStepsToMove != 6)
                    {
                        GameManager.Instance.transferDice = true;
                    }
                    else
                    {
                        GameManager.Instance.selfDice = true;
                    }
                }
            }
            else
            {
                GameManager.Instance.selfDice = true;
            }
            GameManager.Instance.MovePlayerToken(outPlayerPiece);
            GameManager.Instance.AddPathPoint(outPlayerPiece.currentPathPoint);
            outPlayerPiece.previousPathPoint = outPlayerPiece.currentPathPoint;


            GameManager.Instance.numOfStepsToMove = 0;

        }
        GameManager.Instance.canMove = true;
        GameManager.Instance.RollingDiceManager();
        if (moveSteps_Coroutine != null)
        {
            StopCoroutine(nameof(moveSteps_Coroutine));
        }
    }
}
